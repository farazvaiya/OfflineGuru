"""Offline speech recognition via faster-whisper (CTranslate2).

The model is loaded lazily and only from a local directory.  If the directory is
missing the class raises ``ModelUnavailable``; the server surfaces that as a
health warning instead of silently calling a cloud API.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any

import numpy as np

from .config import AsrConfig, Settings
from .realtime import Word

log = logging.getLogger(__name__)


class ModelUnavailable(RuntimeError):
    """Raised when an offline model asset is missing or fails to load."""


@dataclass
class AsrResult:
    text: str
    language: str
    avg_logprob: float
    no_speech_prob: float
    latency_ms: float
    audio_s: float

    @property
    def confidence(self) -> float:
        """Rough 0..1 confidence from the model's own log probabilities."""
        import math

        return max(0.0, min(1.0, math.exp(self.avg_logprob)))


class WhisperAsr:
    def __init__(self, settings: Settings) -> None:
        self.cfg: AsrConfig = settings.asr
        self.model_dir = settings.resolve(self.cfg.model_dir)
        self._model: Any = None

    @property
    def available(self) -> bool:
        return bool(self.model_dir and self.model_dir.is_dir())

    def load(self) -> None:
        if self._model is not None:
            return
        if not self.available:
            raise ModelUnavailable(f"ASR model not found at {self.model_dir}")
        from faster_whisper import WhisperModel

        t0 = time.perf_counter()
        self._model = WhisperModel(
            str(self.model_dir),
            device="cpu",
            compute_type=self.cfg.compute_type,
            cpu_threads=self.cfg.cpu_threads,
            local_files_only=True,
        )
        log.info("ASR loaded in %.0f ms (%s)", (time.perf_counter() - t0) * 1000, self.model_dir)

    def transcribe(self, audio: np.ndarray, beam_size: int | None = None) -> AsrResult:
        if self._model is None:
            self.load()
        if audio.dtype != np.float32:
            audio = audio.astype(np.float32, copy=False)
        t0 = time.perf_counter()
        hotwords = (self.cfg.hotwords or "").strip() or None
        segments, info = self._model.transcribe(
            audio,
            language=self.cfg.language,
            beam_size=beam_size if beam_size is not None else self.cfg.beam_size,
            vad_filter=False,          # the segmenter already did VAD
            condition_on_previous_text=False,  # avoids cross-segment hallucination loops
            temperature=0.0,
            without_timestamps=True,
            hotwords=hotwords,          # bias domain vocabulary (science terms)
        )
        # Materialise once: ``segments`` is a generator and is consumed below.
        seg_list = list(segments)
        text = " ".join(s.text.strip() for s in seg_list if s.text.strip()).strip()
        latency = (time.perf_counter() - t0) * 1000
        probs = [getattr(s, "avg_logprob", -1.0) for s in seg_list] or [-1.0]
        no_speech = [getattr(s, "no_speech_prob", 0.0) for s in seg_list] or [0.0]
        return AsrResult(
            text=text,
            language=getattr(info, "language", self.cfg.language),
            avg_logprob=float(sum(probs) / len(probs)),
            no_speech_prob=float(max(no_speech)),
            latency_ms=latency,
            audio_s=len(audio) / 16000.0,
        )

    def transcribe_words(
        self,
        audio: np.ndarray,
        offset: float = 0.0,
        beam_size: int = 1,
        prompt: str | None = None,
    ) -> list[Word]:
        """Decode a window and return word-level tokens with absolute times.

        This is the streaming entry point: LocalAgreement needs per-word
        timestamps and probabilities to decide what is stable.  Measured cost of
        word timestamps on this CPU: ~2% over a plain decode.
        """
        if self._model is None:
            self.load()
        if audio.dtype != np.float32:
            audio = audio.astype(np.float32, copy=False)
        if audio.size == 0:
            return []
        hotwords = (self.cfg.hotwords or "").strip() or None
        segments, _info = self._model.transcribe(
            audio,
            language=self.cfg.language,
            beam_size=max(1, int(beam_size)),
            vad_filter=False,
            condition_on_previous_text=False,
            temperature=0.0,
            word_timestamps=True,
            initial_prompt=(prompt or None),
            hotwords=hotwords,
        )
        # Whisper pads every input to 30 s and can emit word timestamps past the
        # real audio length. Unclamped, those timestamps push the rolling
        # window's clock forward and every later segment is mis-timed.
        duration = len(audio) / 16000.0
        words: list[Word] = []
        for seg in segments:
            if getattr(seg, "no_speech_prob", 0.0) > 0.9:
                continue
            for word in getattr(seg, "words", None) or []:
                text = (word.word or "").strip()
                if not text:
                    continue
                start = min(max(0.0, float(word.start)), duration)
                end = min(max(start, float(word.end)), duration)
                words.append(
                    Word(
                        text=text,
                        start=offset + start,
                        end=offset + end,
                        prob=float(getattr(word, "probability", 0.0) or 0.0),
                    )
                )
        return words
